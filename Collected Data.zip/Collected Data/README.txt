About the Dataset:

1. Datasets for all 3 case studies are provided.

2. Datasets include the original tweets and comments obtained from Twitter API and PHEME dataset,
including the data obtained on individual users' retweets, liked tweets and replies.

3. There are no tweets for individual users' retweets, liked tweets and replies for case study 1.

4. The tweets and comments are presented in JSON format to present the other details including user id
and date and time of tweet/comment.

5. The results from running the models on the case studies are presented in a CSV format.

